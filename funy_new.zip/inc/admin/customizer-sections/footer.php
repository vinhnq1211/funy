<?php
 $footer = $titan->createThimCustomizerSection( array(
	'name'     => 'Footer',
	'position' => 3,
	'id'       => 'display_footer'
) );
