<?php
$footer->addSubSection( array(
	'name'     => __( 'Copyright Options', 'mabu' ),
	'id'       => 'display_copyright',
	'position' => 12,
) );

$footer->createOption( array(
	'name'    => __( 'Back To Top', 'mabu' ),
	'id'      => 'show_to_top',
	'type'    => 'checkbox',
	'des'     => 'show or hide back to top',
	'default' => true,
) );

$footer->createOption( array(
	'name'        => __( 'Text Color', 'mabu' ),
	'id'          => 'copyright_text_color',
	'type'        => 'color-opacity',
	'default'     => '#878b91',
	'livepreview' => '$("#powered").css("color", value);'
) );

$copy_right = 'http://www.thimpress.com';
$footer->createOption( array(
	'name'        => __( 'Copyright Text', 'mabu' ),
	'id'          => 'copyright_text',
	'type'        => 'textarea',
	'default'     => 'Designed by <a href="' . $copy_right . '">ThimPress.</a> Powered by WordPress.',
	'livepreview' => '$("#powered").html(function(){return "<p>"+ value + "</p>";})'
) );