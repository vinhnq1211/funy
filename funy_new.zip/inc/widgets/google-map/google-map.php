<?php

class Thim_Google_Map_Widget extends Thim_Widget {
	function __construct() {
 		parent::__construct(
			'google-map',
			__( 'Thim: Google Maps', 'mabu' ),
			array(
				'description' => __( 'A Google Maps widget.', 'mabu' ),
				'help'        => '',
				'panels_groups' => array('thim_widget_group')
			),
			array(),
			array(
				'title'      => array(
					'type'  => 'text',
					'label' => __( 'Title', 'mabu' ),
				),
				'map_center' => array(
					'type'        => 'textarea',
					'rows'        => 2,
					'label'       => __( 'Map center', 'mabu' ),
					'description' => __( 'The name of a place, town, city, or even a country. Can be an exact address too.', 'mabu' )
				),
				'settings'   => array(
					'type'        => 'section',
					'label'       => __( 'Settings', 'mabu' ),
					'hide'        => false,
					'description' => __( 'Set map display options.', 'mabu' ),
					'fields'      => array(
						'height'      => array(
							'type'    => 'text',
							'default' => 480,
							'label'   => __( 'Height', 'mabu' )
						),
						'zoom'        => array(
							'type'        => 'slider',
							'label'       => __( 'Zoom level', 'mabu' ),
							'description' => __( 'A value from 0 (the world) to 21 (street level).', 'mabu' ),
							'min'         => 0,
							'max'         => 21,
							'default'     => 12,
							'integer'     => true,

						),
						'scroll_zoom' => array(
							'type'        => 'checkbox',
							'default'     => true,
							'state_name'  => 'interactive',
							'label'       => __( 'Scroll to zoom', 'mabu' ),
							'description' => __( 'Allow scrolling over the map to zoom in or out.', 'mabu' )
						),
						'draggable'   => array(
							'type'        => 'checkbox',
							'default'     => true,
							'state_name'  => 'interactive',
							'label'       => __( 'Draggable', 'mabu' ),
							'description' => __( 'Allow dragging the map to move it around.', 'mabu' )
						)
					)
				),
				'markers'    => array(
					'type'        => 'section',
					'label'       => __( 'Markers', 'mabu' ),
					'hide'        => true,
					'description' => __( 'Use markers to identify points of interest on the map.', 'mabu' ),
					'fields'      => array(
						'marker_at_center' => array(
							'type'    => 'checkbox',
							'default' => true,
							'label'   => __( 'Show marker at map center', 'mabu' )
						),
						'marker_icon'      => array(
							'type'        => 'media',
							'default'     => '',
							'label'       => __( 'Marker Icon', 'mabu' ),
							'description' => __( 'Replaces the default map marker with your own image.', 'mabu' )
						),
//						'markers_draggable' => array(
//							'type'       => 'checkbox',
//							'default'    => false,
//							'state_name' => 'interactive',
//							'label'      => __( 'Draggable markers', 'mabu' )
//						),
						'marker_positions'  => array(
							'type'       => 'repeater',
							'label'      => __( 'Marker positions', 'mabu' ),
							'item_name'  => __( 'Marker', 'mabu' ),
//							'item_label' => array(
//							 'selector'     => "[id*='marker_positions-place']",
//								'update_event' => 'change',
//								'value_method' => 'val'
//							),
							'fields'     => array(
								'place' => array(
									'type'  => 'textarea',
									'rows'  => 2,
									'label' => __( 'Place', 'mabu' )
								)
							)
						)
					)
				),
			)
		);
	}

	function enqueue_frontend_scripts() {
		wp_enqueue_script( 'thim-google-map', TP_THEME_URI . 'inc/widgets/google-map/js/js-google-map.js', array( 'jquery' ), true );
	}

	function get_template_name( $instance ) {
		return 'base';
	}

	function get_style_name( $instance ) {
		return false;
	}

	function get_template_variables( $instance, $args ) {
		$settings = $instance['settings'];
		$markers  = $instance['markers'];
 		$mrkr_src = wp_get_attachment_image_src( $instance['markers']['marker_icon'] );
		{
			return array(
				'map_id'   => md5( $instance['map_center'] ),
				'height'   => $settings['height'],
				'map_data' => array(
					'address'          => $instance['map_center'],
					'zoom'             => $settings['zoom'],
					'scroll-zoom'      => $settings['scroll_zoom'],
					'draggable'        => $settings['draggable'],
					'marker-icon'      => !empty( $mrkr_src ) ? $mrkr_src[0] : '',
 				//	'markers-draggable' => isset( $markers['markers_draggable'] ) ? $markers['markers_draggable'] : '',
					'marker-at-center'  => $markers['marker_at_center'],
					'marker-positions'  => isset( $markers['marker_positions'] ) ? json_encode( $markers['marker_positions'] ) : '',
				)
			);
		}
	}
}
//
function thim_google_map_widget() {
	register_widget( 'Thim_Google_Map_Widget' );
}

add_action( 'widgets_init', 'thim_google_map_widget' );