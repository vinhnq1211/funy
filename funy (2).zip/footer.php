<?php
/**
 * Created by PhpStorm.
 * User: vinhnq
 * Date: 24/12/2015
 * Time: 10:21 CH
 */
?>

                <?php wp_footer(); ?>
            </section>
        </div>
    </body>
</html>