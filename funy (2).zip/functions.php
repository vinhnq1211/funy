<?php
/**
 * Created by PhpStorm.
 * User: vinhnq
 * Date: 24/12/2015
 * Time: 10:20 CH
 */

if ( !function_exists( 'funy_setup' ) ) :
    /**
     * Sets up theme defaults and registers support for various WordPress features.
     *
     * Note that this function is hooked into the after_setup_theme hook, which
     * runs before the init hook. The init hook is too late for some features, such
     * as indicating support for post thumbnails.
     */
    function funy_setup() {

        /*
         * Make theme available for translation.
         * Translations can be filed in the /languages/ directory.
         * If you're building a theme based on thim, use a find and replace
         * to change 'mabu' to the name of your theme in all the template files
         */
        load_theme_textdomain( 'funy', get_template_directory() . '/languages' );

        // Add default posts and comments RSS feed links to head.
        add_theme_support( 'automatic-feed-links' );

        /*
         * Enable support for Post Thumbnails on posts and pages.
         *
         * @link http://codex.wordpress.org/Function_Reference/add_theme_support#Post_Thumbnails
         */
        add_theme_support( 'post-thumbnails' );
        // This theme uses wp_nav_menu() in one location.
        register_nav_menus( array(
            'primary' => __( 'Primary Menu', 'funy' ),
        ) );

        /*
         * Switch default core markup for search form, comment form, and comments
         * to output valid HTML5.
         */
        add_theme_support( 'html5', array(
            'search-form', 'comment-form', 'comment-list', 'gallery', 'caption',
        ) );

        /*
         * Enable support for Post Formats.
         * See http://codex.wordpress.org/Post_Formats
         */
        add_theme_support( 'post-formats', array(
            'aside', 'image', 'video', 'quote', 'link', 'gallery', 'audio'
        ) );

        // Set up the WordPress core custom background feature.
        add_theme_support( 'custom-background', apply_filters( 'vina_custom_background_args', array(
            'default-color' => 'ffffff',
            'default-image' => '',
        ) ) );
    }

endif; // thim_setup
add_action( 'after_setup_theme', 'funy_setup' );


/**
 * Register widget area.
 *
 * @link http://codex.wordpress.org/Function_Reference/register_sidebar
 */

function funy_widgets_init() {
    global $theme_options_data;
    register_sidebar( array(
        'name'          => __( 'Sidebar', 'funy' ),
        'id'            => 'sidebar-1',
        'description'   => '',
        'before_widget' => '<aside id="%1$s" class="widget %2$s">',
        'after_widget'  => '</aside>',
        'before_title'  => '<h3 class="widget-title"><span>',
        'after_title'   => '</span></h3>',
    ) );
        register_sidebar( array(
            'name'          => __( 'Menu Left', 'funy' ),
            'id'            => 'menu_left',
            'description'   => 'header right using width header layout 02',
            'before_widget' => '<li id="%1$s" class="widget %2$s">',
            'after_widget'  => '</li>',
            'before_title'  => '<h3 class="widget-title">',
            'after_title'   => '</h3>',
        ) );


    register_sidebar( array(
        'name'          => 'Menu Right',
        'id'            => 'menu_right',
        'description'   => __( 'Menu Right', 'funy' ),
        'before_widget' => '<li class="widget %2$s">',
        'after_widget'  => '</li>',
        'before_title'  => '<h3>',
        'after_title'   => '</h3>',
    ) );

    register_sidebar( array(
        'name'          => __( 'Offcanvas Sidebar', 'funy' ),
        'id'            => 'offcanvas_sidebar',
        'description'   => 'Offcanvas Sidebar',
        'before_widget' => '<aside id="%1$s" class="widget %2$s">',
        'after_widget'  => '</aside>',
        'before_title'  => '<h3 class="widget-title">',
        'after_title'   => '</h3>',
    ) );
    register_sidebar( array(
        'name'          => __( 'Main Bottom', 'funy' ),
        'id'            => 'main-bottom',
        'description'   => '',
        'before_widget' => '<aside id="%1$s" class="widget %2$s">',
        'after_widget'  => '</aside>',
        'before_title'  => '<h3 class="widget-title">',
        'after_title'   => '</h3>',
    ) );
    register_sidebar( array(
        'name'          => __( 'Footer', 'funy' ),
        'id'            => 'footer',
        'description'   => '',
        'before_widget' => '<aside id="%1$s" class="widget %2$s">',
        'after_widget'  => '</aside>',
        'before_title'  => '<h3 class="widget-title">',
        'after_title'   => '</h3>',
    ) );
}
add_action( 'widgets_init', 'funy_widgets_init' );


/**
 * Enqueue scripts and styles.
 */
function funy_scripts() {

    wp_enqueue_style( 'funy-bootstrap-css', get_bloginfo("template_url") . '/css/bootstrap.min.css', array() );
    wp_enqueue_style( 'funy-main', get_bloginfo("template_url") . '/css/main.css', array() );
    wp_enqueue_script( 'funy-js', 'http://code.jquery.com/jquery-2.1.4.min.js', array(), '', true );
    wp_enqueue_script( 'funy-bootstrap-js', get_bloginfo("template_url") . '/js/bootstrap.min.js', array(), '', true );
}
add_action( 'wp_enqueue_scripts', 'funy_scripts' );

if( class_exists( 'WP_Customize_Control' ) ):
    class WP_Customize_Textarea_Control extends WP_Customize_Control {
        public $type = 'textarea';

        public function render_content() {
            ?>
            <label>
                <span class="customize-control-title"><?php echo esc_html( $this->label ); ?></span>
                <textarea rows="5" style="width:100%;" <?php $this->link(); ?>><?php echo esc_textarea( $this->value() ); ?></textarea>
            </label>
            <?php
        }
    }
endif;

require get_template_directory() . '/inc/custom-functions.php';

// Add Customizer functionality.
require get_template_directory() . '/inc/customizer.php';
require get_template_directory() . '/framework/Titan-Framework-master/titan-framework.php';
require get_template_directory() . '/inc/customizer-options.php';
global $theme_options_data;
$theme_options_data = get_theme_mods();

// include widgets
//pannel Widget Group
function vinathemes_widget_group( $tabs ) {
    $tabs[] = array(
        'title'  => __( 'Thim Widget', 'mabu' ),
        'filter' => array(
            'groups' => array( 'thim_widget_group' )
        )
    );
    return $tabs;
}
add_filter( 'siteorigin_panels_widget_dialog_tabs', 'vinathemes_widget_group', 19 );
require get_template_directory() . '/framework/class-widgets.php';
require get_template_directory() . '/inc/widgets/widgets.php';
