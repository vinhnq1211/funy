<?php
/**
 * Created by PhpStorm.
 * User: vinhnq
 * Date: 24/12/2015
 * Time: 10:17 CH
 */
get_header();?>

<?php get_footer();?>
