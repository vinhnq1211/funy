<?php

class Heading_Widget extends Vinathemes_Widget {

	function __construct() {
		parent::__construct(
			'heading',
			__( 'Vinathemes: Heading', 'funy' ),
			array(
				'description'   => __( 'Add heading text', 'funy' ),
				'help'          => '',
				'panels_groups' => array( 'vinathemes_widget_group' )
			),
			array(),
			array(
				'title'               => array(
					'type'    => 'text',
					'label'   => __( 'Heading Text', 'funy' ),
					'default' => '',
				),

				'sub-title'           => array(
					'type'    => 'text',
					'label'   => __( 'Sub Heading', 'funy' ),
					'default' => '',
					'allow_html_formatting' => true,
				),
				
				'line'                => array(
					'type'    => 'checkbox',
					'label'   => __( 'Show Separator', 'funy' ),
					'default' => false,
				),
				'textcolor'           => array(
					'type'    => 'color',
					'label'   => __( 'Text Heading color', 'funy' ),
					'default' => '',
				),
				'size'                => array(
					"type"    => "select",
					"label"   => __( "Size Heading", 'funy' ),
					"options" => array(
						"h2" => __( "h2", 'funy' ),
						"h3" => __( "h3", 'funy' ),
						"h4" => __( "h4", 'funy' ),
						"h5" => __( "h5", 'funy' ),
						"h6" => __( "h6", 'funy' ),
					),
					"default" => "h3"
				),

				'heading_padding'           => array(
					'type'    => 'text',
					'label'   => __( 'Heading Padding', 'funy' ),
					'default' => '',
				),

				'font_heading'        => array(
					"type"          => "select",
					"label"         => __( "Font Heading", 'funy' ),
					"default"       => "default",
					"options"       => array(
						"default" => __( "Default", 'funy' ),
						"custom"  => __( "Custom", 'funy' )
					),
					"description"   => __( "Select Font heading.", 'funy' ),
					'state_emitter' => array(
						'callback' => 'select',
						'args'     => array( 'font_heading_type' )
					)
				),
				'custom_font_heading' => array(
					'type'          => 'section',
					'label'         => __( 'Custom Font Heading', 'funy' ),
					'hide'          => true,
					'state_handler' => array(
						'font_heading_type[custom]'  => array( 'show' ),
						'font_heading_type[default]' => array( 'hide' ),
					),
					'fields'        => array(
						'custom_font_size'   => array(
							"type"        => "number",
							"label"       => __( "Font Size", 'funy' ),
							"suffix"      => "px",
							"default"     => "14",
							"description" => __( "custom font size", 'funy' ),
							"class"       => "color-mini",
						),
						'custom_font_weight' => array(
							"type"        => "select",
							"label"       => __( "Custom Font Weight", 'funy' ),
							"options"     => array(
								"normal" => __( "Normal", 'funy' ),
								"bold"   => __( "Bold", 'funy' ),
								"100"    => __( "100", 'funy' ),
								"200"    => __( "200", 'funy' ),
								"300"    => __( "300", 'funy' ),
								"400"    => __( "400", 'funy' ),
								"500"    => __( "500", 'funy' ),
								"600"    => __( "600", 'funy' ),
								"700"    => __( "700", 'funy' ),
								"800"    => __( "800", 'funy' ),
								"900"    => __( "900", 'funy' )
							),
							"description" => __( "Select Custom Font Weight", 'funy' ),
							"class"       => "color-mini",
						),
						'custom_font_style'  => array(
							"type"        => "select",
							"label"       => __( "Custom Font Style", 'funy' ),
							"options"     => array(
								"inherit" => __( "inherit", 'funy' ),
								"initial" => __( "initial", 'funy' ),
								"italic"  => __( "italic", 'funy' ),
								"normal"  => __( "normal", 'funy' ),
								"oblique" => __( "oblique", 'funy' )
							),
							"description" => __( "Select Custom Font Style", 'funy' ),
							"class"       => "color-mini",
						),
					),
				),

				'css_animation'       => array(
					"type"    => "select",
					"label"   => __( "CSS Animation", 'funy' ),
					"options" => array(
						""              => __( "No", 'funy' ),
						"top-to-bottom" => __( "Top to bottom", 'funy' ),
						"bottom-to-top" => __( "Bottom to top", 'funy' ),
						"left-to-right" => __( "Left to right", 'funy' ),
						"right-to-left" => __( "Right to left", 'funy' ),
						"appear"        => __( "Appear from center", 'funy' )
					),
				),

				'align'       => array(
					"type"    => "select",
					"label"   => __( "Align", 'funy' ),
					"options" => array(
						"center"  	=> __( "Center", 'funy' ),
						"left"		=> __( "Left", 'funy' ),
						"right" 	=> __( "Right", 'funy' )
					),
				),

			),
			get_template_directory() . '/inc/widgets/heading/'
		);
	}

	/**
	 * Initialize the CTA widget
	 */

	function get_template_name( $instance ) {
		return 'base';
	}

	function get_style_name( $instance ) {
		return false;
	}

}

function vinathemes_heading_register_widget() {
	register_widget( 'Heading_Widget' );
}

add_action( 'widgets_init', 'vinathemes_heading_register_widget' );