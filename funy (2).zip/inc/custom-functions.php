<?php
/**
 * Created by PhpStorm.
 * User: vinhnq
 * Date: 24/12/2015
 * Time: 10:34 CH
 */

function vinathemes_getCSSAnimation( $css_animation ) {
    $output = '';
    if ( $css_animation != '' ) {
        $output = ' wpb_animate_when_almost_visible wpb_' . $css_animation;
    }

    return $output;
}

function excerpt( $limit ) {
    $content = get_the_excerpt();
    $content = apply_filters( 'the_content', $content );
    $content = str_replace( ']]>', ']]&gt;', $content );
    $content = explode( ' ', $content, $limit );
    array_pop( $content );
    $content = implode( " ", $content );

    return $content;
}