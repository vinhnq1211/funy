<?php

/*
 * Titan Framework options sample code. We've placed here some
 * working examples to get your feet wet
 * @see	http://www.titanframework.net/get-started/
 */


add_action( 'tf_create_options', 'funy_create_options' );

/**
 * Initialize Titan & options here
 */
function funy_create_options() {

	$titan = TitanFramework::getInstance( 'funy' );
	
	
	/**
	 * Create a Theme Customizer panel where we can edit some options.
	 * You should put options here that change the look of your theme.
	 */

	// General option

	$section = $titan->createThemeCustomizerSection( array(
	    'name' => __( 'General', 'funy' ),
	) );

	$section->createOption( array(
		'name'    => __( 'Logo', 'funy' ),
		'id'      => 'logo',
		'type'    => 'upload',
		'desc'    => __( 'Upload your logo', 'funy' ),
		'default' => '',
	) );

	$section->createOption( array(
		'name' => __( 'Favicon', 'funy' ),
		'id'   => 'favicon',
		'type' => 'upload',
		'desc' => __( 'Upload your favicon', 'funy' ),
		'default' => '',
	) );

	// Top bar option

	$top_bar = $titan->createThemeCustomizerSection( array(
		'name' => __( 'Top bar', 'funy' ),
	) );
	$top_bar->createOption( array(
		'name'    => __( 'Show top-bar', 'funy' ),
		'id'      => 'show_top_bar',
		'type'    => 'select',
		'options' => array(
			'1' => __( 'Yes', 'funy' ),
			'0' => __( 'No', 'funy' ),
		),
		'default' => '1',
	) );
	$top_bar->createOption( array(
		"name"    => __( "Background color", 'funy' ),
		"desc"    => __( "Pick a background color for top-bar", 'funy' ),
		"id"      => "bg_top_bar_color",
		"default" => "#252525",
		"type"    => "color"
	) );
	$top_bar->createOption( array(
		"name"    => __( "Text color", 'funy' ),
		"desc"    => __( "Pick a text color for top-bar", 'funy' ),
		"id"      => "text_top_bar_color",
		"default" => "#ffffff",
		"type"    => "color"
	) );
	$top_bar->createOption( array(
		"name"    => __( "Link color", 'funy' ),
		"desc"    => __( "Pick a link color for top-bar", 'funy' ),
		"id"      => "link_top_bar_color",
		"default" => "#c4573a",
		"type"    => "color"
	) );

	// Typography option

	$section1 = $titan->createThemeCustomizerSection( array(
		'name' => __( 'Typography', 'funy' ),
	) );



}